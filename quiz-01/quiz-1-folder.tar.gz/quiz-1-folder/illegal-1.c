#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(  )
{
  int arr1[5];
  int arr2[5];

  arr1 = arr2;

  return EXIT_SUCCESS;
}
