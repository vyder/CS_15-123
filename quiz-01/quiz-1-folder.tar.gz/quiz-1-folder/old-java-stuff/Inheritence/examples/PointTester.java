class PointTester
{
   public static void main( String args[] )
   {
	Point2D p2 = new Point2D();
	
	p2.setX( 22 );
        p2.setY( 7 );
	
	System.out.println( "p2 = " + p2 );
   }
} // EOF