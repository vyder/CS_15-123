import java.util.*;
import java.io.*;

public class Test
{

	public static void main(String[] args) throws Exception
	{
		BufferedReader infile = new BufferedReader( new FileReader( "input1.txt" ) );
		String line = infile.readLine();
		HashMap map = new HashMap();

		while (line != null )
		{
			StringTokenizer st = new StringTokenizer( line );

			while (st.hasMoreTokens() )
			{
					String token = st.nextToken();
					if (!map.containsKey( token ))
					{
						map.put( token, new Integer(1) );
						//System.out.println("Just put " + token + " map now has " + map.size() + " words in it" );
					}
					else
					{
						int oldVal = ((Integer)map.get(token)).intValue();
						map.put( token, new Integer(oldVal+1)  );
						//System.out.println("Just incrd freq for " + token + " map now has " + map.size() + " words in it" );
					}
			}
			line = infile.readLine();
		}//END WHILE

		// STEP 1 print the map as is

		System.out.println( map );

		// STEP 2: Build then print a list of strings where each String is the ToString of an indiv map pair sorted by word

		Set words = map.keySet();
		Object[] arr = map.keySet().toArray();
		Arrays.sort( arr );
		ArrayList l = new ArrayList() ;
		for (int i=0 ; i<arr.length ; ++i )
			l.add( arr[i] + "=" + map.get( arr[i] ) );
		System.out.println( l );

		// STEP 3: Same drill but sorted by freq






	} // END MAIN
} //EOF