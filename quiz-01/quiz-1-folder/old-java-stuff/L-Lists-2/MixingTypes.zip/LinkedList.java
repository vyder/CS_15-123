public class LinkedList
{
   private ListElement head;  // pointer to a list of elements

   public LinkedList()
   {
     head=null;
   } // END C'TOR

   public void insertAtFront( Object data )
   {
     head = new ListElement( data, head );
   } //END INSERT AT FRONT

   public void print()
   {
	 System.out.print( "\nThe List: ");
   	 ListElement curr = head;
   	 while (curr !=null)
   	 {
   	 	System.out.print( curr.getData() + " " );
   	 	if (curr.getNext() !=null )
   	 		System.out.print( "--> " );
   	 	else
   	 		System.out.println();

		curr = curr.getNext();   // advance to next element
   	 }
   } //END PRINT
}//EOF