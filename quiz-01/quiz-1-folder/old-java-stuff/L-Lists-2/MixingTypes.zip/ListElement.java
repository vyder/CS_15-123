/* ListElement class definition

	Defines its data fiels as type Object
	This allows users of ListElement to pass ANY
	class type into a ListElement's Constructor

*/

public class ListElement
{
  private Object data; // any class that implements Comparable can be sent in
  private ListElement next;

  public ListElement( Object data, ListElement next)
  {
     setData( data);
     setNext( next );
  }
  public void setData( Object data )
  {
     this.data = data; // this.data is the member field, data is the incoming arg
  }
  public Object getData()
  {
     return data;
  }
  public void setNext( ListElement next )
  {
     this.next = next; // this.next is the member field, next is the incoming
  }
  public ListElement getNext()
  {
     return next;
  }

}//EOF