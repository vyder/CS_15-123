import java.util.*;
import java.io.*;

public class Test
{
	public static void main(String[] args) throws Exception
	{
		BufferedReader infile = new BufferedReader( new FileReader( "dictionary.txt" ) );
		HashMap map = new HashMap();
		String word = infile.readLine();
		int wordCount = 0;
		while ( word  != null )
		{
			// sort the word. Sorted form becomes key
			String sortedWord = sortWord( word );
			++wordCount;

			// if key ALREADY exists in map - add new word to old value (ArrayList)

			if ( map.containsKey(sortedWord) )
			{
				ArrayList equivalentWords = (ArrayList) map.get( sortedWord );
				equivalentWords.add( word );
				map.put( sortedWord, equivalentWords );
			}
			else // create new value (ArrayList) with this key and put pair into Map
			{
				ArrayList equivalentWords = new ArrayList();
			    equivalentWords.add( word );
				map.put( sortedWord, equivalentWords );
			}

			word = infile.readLine(); // read next word/line from file
		}
		infile.close();

		// P H A S E - II  read the file of jumbled wrods

		infile = new BufferedReader( new FileReader( "jumbles.txt" ) );
        word = infile.readLine();
		while ( word  != null )
		{
			// sort the word. Sorted form becomes key
			String sortedWord = sortWord( word );

			// if key ALREADY exists in map - add new word to old value (ArrayList)
			if ( map.containsKey(sortedWord) )
			{
				ArrayList equivalentWords = (ArrayList) map.get( sortedWord );
				System.out.println( word +": " + equivalentWords );
			}

			word = infile.readLine(); // read next word/line from file
		}
		infile.close();

	} // END MAIN

	public static String sortWord( String word )
	{
			StringBuffer sortedWord = new StringBuffer( 50 );
			char c[] = word.toCharArray();
			Object o[] = new Object[c.length];
			for (int i=0 ; i < c.length ; ++i )
				o[i] = c[i] + "";
			Arrays.sort( o );

			for (int i=0 ; i < o.length ; ++i )
				sortedWord.append( o[i] );
			return new String( sortedWord );
	}
} //EOF