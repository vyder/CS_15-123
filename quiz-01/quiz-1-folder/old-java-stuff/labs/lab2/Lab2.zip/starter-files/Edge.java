/*
	Graph.java

	myName:
	myAndrewID:
*/

public class Edge
{
	// declare private fields: dest, weight
	// declare private pointer: next  to point to the next Edge in the list

	// declare public methods get and set for each of the above 3 fields
}
