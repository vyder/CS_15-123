NOTE: I am only giving you the Graph.class file so you can run it and see it's behaviour but
you can't get the original source code from the compiled class file!


Here is how you run the solution files I am giving you.
-------------------------------------------------------


1)  Copy Lab1.java, Graph.class (my Graph.class) and graphdata.txt into a directory

2)  It is easier if you copy them into a dir like c:\TEMP rather than the desktop becuase
	cd'ing into the destop dir is a lot of typing

3)  Open a command window and cd into the directory where the solution files are

4)  At the command prompt type     javac Lab1.java  (then hit Enter)

5)  Look in your doirectory and verify the Lab1.class and Graph.class files were created. 
This means both compiled sucessfully

6)  Then type:  java Lab1  graphdata.txt  (then hit Enter)

You should see the program execute and dump it's output to the screen. If your java command is rejected then 
you need to set your path varible to point to the bin directory where Java is installed.

Please contact tim hoffman or any of your Course Assistants ASAP if you can't execute this solution

Jason Weill
jweill@andrew.cmu.edu 

Gary Garvin
ggarvin@andrew.cmu.edu 

Xia Geng 
xgeng@andrew.cmu.edu 

Yeming Shi
yemings@andrew.cmu.edu 