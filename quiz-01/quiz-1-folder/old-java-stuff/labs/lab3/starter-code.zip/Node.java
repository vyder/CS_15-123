public class Node
{
	String data;
	Node left,right;
	
	public Node( String data )
	{
		this.data = data;
	}
	
	public Node getLeft()
	{
		return left;
	}
	
	public Node getRight()
	{
		return right;
	}
	
	
	public void setRight( Node r)
	{
		right = r;
	}
	
	public void setLeft( Node l)
	{
		left = l;
	}
	
	public String getData()
	{
		return data;
	}
	
	public void setData( String data)
	{
		this.data = data;
	}
	

} // EOF