

// MyName:

// My Andrew ID:


import java.io.*;
import java.util.*;

public class Tree
{
	private Node root;

	public Tree( String inFileName )
	{
		root = null;
		readFile( inFileName );
	}

	private void readFile( String inFileName )
	{

		StreamTokenizer st = null;  /* tokenizes br */
		int wordsRead = 0;

		try
		{
			st = new StreamTokenizer( new BufferedReader( new FileReader( inFileName ) ) );
		}
		catch (Exception e)
		{
			System.out.println("Can't open input file: " + inFileName );
			System.exit(0);
		}

		System.out.println("Each '*' == 1000 words inserted into Tree...");
		int lnCnt=0;
		try
		{
			while (st.nextToken() != StreamTokenizer.TT_EOF)
			{
				String w = st.sval; // we expect every token is a string not a number
				insert( w );
				if (++wordsRead % 1000 == 0)
					System.out.print("*");
			}
			System.out.println("\n");
		}
		catch( Exception e)
		{
			System.out.print("I/O Exception in input file at line # " + lnCnt );
			System.exit(0);
		}

	} // END C'Tor

	public void insert( String data )
	{
		if (root == null)
			root = new Node( data );
		else
			insertHelper( root, data );

	}
	private void insertHelper( Node root, String data )
	{
		int result = data.compareTo( root.getData() );

		if (result==0) System.out.println("Ignoring insertion of duplicate data: " + data );

		if (result < 0) // go left
		{
			if (root.getLeft() == null)
				root.setLeft( new Node( data ) );
			else
				insertHelper( root.getLeft(), data );
		}
		if (result > 0) // go right
		{
			if (root.getRight() == null)
				root.setRight( new Node( data ) );
			else
				insertHelper( root.getRight(), data );
		}


	} // END insertHelper


	// all of the following methods require recursive helper methods
	// because they require the root be passed in and recursed on.
	// the code in main can't pass in the root

	// prints node out in sorted order
	public void inOrderPrint()
	{
		inOrderPrintHelper( root );
		System.out.println();
	}
	private void inOrderPrintHelper( Node root )
	{
		if (root==null) return;
		inOrderPrintHelper( root.getLeft() );
		System.out.print( root.getData() + " " );
		inOrderPrintHelper( root.getRight() );
	}

	// you write preOrderPrint, postOrderPrint & their helpers
	// the helpers must be *private *

	// vist (i.e. print), go left, go right
	public void preOrderPrint()
	{
		// YOUR CODE HERE
	}
	private void preOrderPrintHelper( Node root )
	{
		// YOUR CODE HERE
	}

	// prints node out in pre order L,R,V
	public void postOrderPrint()
	{
		// YOUR CODE HERE	}
	}
	private void postOrderPrintHelper( Node root )
	{
		// YOUR CODE HERE
	}

	// returns a count of the number of total nodes
	public int countNodes()
	{
		return countNodesHelper( root );
	}
	private int countNodesHelper( Node root)
	{
		return 0; // remove this and replace with your code
		// YOUR CODE HERE
	}

	// returns a count of the number of leaves in the
	public int countLeaves()
	{
		return countLeavesHelper(root);
	}

	private int countLeavesHelper(Node root)
	{
		return 0; // remove this and replace with your code
		// YOUR CODE HERE
	}

	// return depth of tree - i.e. number of levels
	public int depth()
	{
		return depthHelper( root );
	}
	private int depthHelper( Node root )
	{
		return 0; // remove this and replace with your code
		// YOUR CODE HERE
	}

	public boolean search( String data )
	{
		return searchHelper( root, data );
	}

	private boolean searchHelper( Node root, String data )
	{
		return false; // remove this and replace with your code
		// YOUR CODE HERE
	}

	// returns a ref to an array that is as long as the tree is deep containing the node counts at each level
	public int[] calcLevelCounts()
	{
		int levelCounts[] = new int[ depth() ];
		calcLevelCounts( root, levelCounts, 0 );
		return levelCounts;
	}

	// private helper method recurses down the treee and back up - counting nodes at each level
	private void calcLevelCounts( Node root, int[] levelCounts, int level )
	{
		// YOUR CODE HERE
	}

} //EOF
