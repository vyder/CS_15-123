// THIS FILE IS GIVEN TO YOU AS COMPLETE
// BUT YOU MAY MODIFY IT AS YOU WISH
// your name:
// your section:

import java.util.*;

public class Clock
{
  private long startTime; // timestamp in milliseconds since 1970/1/1/ 00:00:00.000
  private long stopTime; // timestamp in milliseconds since 1970/1/1/ 00:00:00.000

  public Clock()
  {
    startTime=stopTime=0;
  }

  public double getElapsedTime()
  {
    return (double) ((stopTime-startTime)/1000.0);
  }

  public void start()
  {
    startTime = new java.util.Date().getTime();
  }

  public void stop()
  {
    stopTime = new java.util.Date().getTime();
  }

  public String toString()
  {
   return getElapsedTime() + " sec.";
  }
} // EOF CLOCK CLASS
