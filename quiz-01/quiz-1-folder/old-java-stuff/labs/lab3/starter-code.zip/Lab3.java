import java.io.*;

public class Lab3
{
	private static BufferedReader kbd = new BufferedReader( new InputStreamReader( System.in ) );

	public static void main( String args[] ) throws IOException
	{
		Clock stopWatch = new Clock();
		System.out.println("\nReading: " + args[0] + " into myTree");
		stopWatch.start();
		Tree myTree = new Tree( args[0] ); /* C'tor reads & inserts entire input file onto tree */
		stopWatch.stop();
		System.out.println("Done. MyTree read and built in " + stopWatch + "\n" );

		// only do prints on small files <= 100 nodes

		if ( myTree.countNodes() > 100)
			System.out.println("Tree > 100 Nodes. SKIPPING PRINTS");
		else
		{
			System.out.println("\nPre Order print of myTree:");
			myTree.preOrderPrint();

			System.out.println("\n\nIn Order print of myTree:");
			myTree.inOrderPrint();

			System.out.println("\n\nPost Order print of myTree:");
			myTree.postOrderPrint();
		}

		System.out.println("\n");

		// Report # of nodes in Tree

		System.out.println("myTree has " + myTree.countNodes() + " nodes");

		// Report # of leaves in Tree

		System.out.println("myTree has " + myTree.countLeaves() + " leaves");

		// Report # of levels (depth)

		int depth = myTree.depth();
		System.out.println("myTree has depth: " +  depth);

		// calculate and report the node counts at each level

		System.out.println("\nLevel Counts\n");

		int[] levelCounts = myTree.calcLevelCounts();

		for (int i=0 ; i< levelCounts.length ; ++i )
			System.out.println("level " + i + ": " + levelCounts[i] );

		do // MENU LOOP
		{
			System.out.print("Enter 'S'earch, 'I'nsert, 'P'rint, 'Q'uit: ");
			String response = kbd.readLine();
			if (response.equalsIgnoreCase("S"))
				doSearch(myTree);
			else if (response.equalsIgnoreCase("I"))
				doInsert( myTree );
			else if (response.equalsIgnoreCase("Q"))
				doQuit();
			else if (response.equalsIgnoreCase("P"))
			{
				doPrint( myTree );
			}
			else
				System.out.println("Unrecognized command. Try again.");
		} while (true);

	} //END main

	public static void doSearch( Tree t ) throws IOException
	{
		System.out.print("Enter word to search for: " );
		String target = kbd.readLine();
		if (t.search( target ))
			System.out.println(target + " found");
		else
			System.out.println(target + " NOT found");
	}

	public static void doInsert( Tree t ) throws IOException
	{

		System.out.println("Enter word to insert: " );
		String target = kbd.readLine();
		t.insert( target );
	}

	public static void doPrint( Tree t )
	{
		t.inOrderPrint();
	}

	public static void doQuit()
	{
		System.exit(0);
	}
} //EOF


