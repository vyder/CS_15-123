import java.io.*;
import java.util.*;

public class Tree
{
	private Node root;
	private boolean prefix; // strores prefix property or most recent search

	int charCnt;
	public Tree()
	{
		root = null;
	}
	public Tree( String inFileName )
	{
		this();	
		readFile( inFileName );
	}
	
	private void readFile( String inFileName )
	{
		// DECLARE BUFFERED READER ON TOKENIZER ON FILEREADER
		// USE TRY CATCH
		
		FileReader fr = null;		/* actual disk I/O */
		BufferedReader br = null;   /* buffers on top of fr for efficiency */
		StreamTokenizer st = null;  /* tokenizes br */
		int wordsRead = 0;
		
		try
		{
			fr =new FileReader( inFileName );
			br = new BufferedReader( fr );
			st = new StreamTokenizer( br );
		}
		catch (Exception e)
		{
			System.out.println("Can't open input file: " + inFileName );
			System.exit(0);
		}

		System.out.println("\nLoading the scrabble dictionary. Each '*' == 10,000 words inserted into dictionary BST...");
		int lnCnt=0;
		try
		{
			while (st.nextToken() != StreamTokenizer.TT_EOF)
			{
				String w = st.sval; // we expect every token is a string not a number
				insert( w );
				if (++wordsRead % 10000 == 0)
					System.out.print("*");
			}			
		}
		catch( Exception e)
		{
			System.out.print("I/O Exception in input file at line # " + lnCnt );
			System.exit(0);
		}
	
	} // 
	
	public boolean isPrefix()
	{
		return prefix ;
	}
	
	public void setPrefix( boolean prefix )
	{
		this.prefix = prefix ;
	}
	
	public void insert( String data )
	{
		if (root == null) 
			root = new Node( data );
		else
			insertHelper( root, data );
		
	}
	private void insertHelper( Node root, String data )
	{
		int result = data.compareTo( root.getData() );
		
		if (result < 0) // go left
		{
			if (root.getLeft() == null)
				root.setLeft( new Node( data ) );
			else
				insertHelper( root.getLeft(), data );
		}
		if (result > 0) // go right
		{
			if (root.getRight() == null)
				root.setRight( new Node( data ) );
			else
				insertHelper( root.getRight(), data );
		}
	
		//if (result==0) System.out.println("Ignoring insertion of duplicate data: " + data );	
	} // END insertHelper
	
		
	// all of the following methods require recursive helper methods
	// because they require the root be passed in and recursed on.
	// the code in main can't pass in the root
	
	// prints node out in sorted order
	public void inOrderPrint()
	{
		charCnt=0;
		inOrderPrintHelper( root );	
		charCnt=0;
	}
	private void inOrderPrintHelper( Node root )
	{
		
		if (root==null) return;
		inOrderPrintHelper( root.getLeft() );
		System.out.print( root.getData() + " " );
		charCnt += root.getData().length() + 1;
		if (charCnt > 60)
		{
			charCnt=0;
			System.out.println();
		}
		inOrderPrintHelper( root.getRight() );
	}
		
	// you write preOrderPrint, postOrderPrint & their helpers
	// the helpers must be *private *
	
	// vist (i.e. print), go left, go right
	public void preOrderPrint()
	{
		preOrderPrintHelper( root );
	}
	public void preOrderPrintHelper( Node root )
	{
		if (root==null) return;
		System.out.println( root.getData() );
		inOrderPrintHelper( root.getLeft() );
		inOrderPrintHelper( root.getRight() );		
	}
	
	// prints node out in pre order L,R,V
	public void postOrderPrint()
	{
		postOrderPrintHelper( root );
	}
	// go left, go right, visit (i.e. print)
	private void postOrderPrintHelper( Node root )
	{		
		if (root==null) return;
		System.out.println( root.getData() );
		inOrderPrintHelper( root.getLeft() );
		inOrderPrintHelper( root.getRight() );			
	}
	
	// returns a count of the number of total nodes 
	public int countNodes()
	{
		return countNodesHelper( root );
	}
	private int countNodesHelper( Node root)
	{
		if (root==null) return 0;
		return 1 + countNodesHelper(root.getLeft())+ countNodesHelper(root.getRight());
	}
	
	// returns a count of the number of leaves in the 
	public int countLeaves()
	{
		return countLeavesHelper(root);
	}
	public int countLeavesHelper(Node root)
	{
		if (root==null) return 0;
		if ( root.getLeft() == null  && root.getRight() == null ) return 1;
		return countLeavesHelper(root.getLeft())+ countLeavesHelper(root.getRight());
	}
	
	
	// return depth of tree - i.e. number of levels
	public int depth()
	{
		return depthHelper( root );
	}
	public int depthHelper( Node root )
	{
		if (root==null) return 0;
		return 1 + Math.max( depthHelper(root.getLeft()), depthHelper(root.getRight()) );
	}
	
	public boolean search( String data )
	{
		setPrefix( false );
		return searchHelper( root, data );	
	}
	
	private boolean searchHelper( Node root, String data )
	{
		if (root==null) return false;
		int result = data.compareTo( root.getData() );
		if (root.getData().startsWith( data ))
			setPrefix(true);
		
		if (result<0)
			return searchHelper( root.getLeft(), data );
		else if (result>0)
			return searchHelper( root.getRight(), data );
		else // result == 0   match!
			return true; 
	}		
	
} //EOF
