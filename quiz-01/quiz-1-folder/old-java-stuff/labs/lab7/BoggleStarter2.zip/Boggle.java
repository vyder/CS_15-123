/*  Time-stamp: 12:10 PM 10/23/2002 tim hoffman
	Boggle.java

	Generates a Boggle Board and solves the board by searching the scrabble dictionary for words
	formed from the grid.  The pruning hueristic prevents unnecessary searches, keeping runtime
	fairly quick for even large grids.
*/
import java.io.*;
import java.util.Random;

public class Boggle
{
	private Tree dictionary, wordsFound;

	private int dimension; // Boggle board is n X n grid of chars
	private String board[][]; // board is n x n array of chars BUT we store each as String for convenience
	private String alphabet[] = { "a", "b", "c", "d", "e", "f", "a", "g", "h", "i", "j", "k", "l", "e", "m",
		"n", "o", "p", "q", "r", "s", "i", "t" , "u", "v", "w", "x", "o", "y", "z", "qu", "u" };

	// ---------------------------------------------------------------------------------------------------------
	// default C'tor reads scrabble.txt into dictionary and creates an empty output tree
	private Boggle()
	{
		dictionary = new Tree( "scrabble.txt" );
		wordsFound = new Tree(); // empty tree created - ready for insertions
	}

	// ---------------------------------------------------------------------------------------------------------
	// 2nd C'tor takes only an int for the dimension of the board, fills using  Random letters
    public Boggle( int dimension )
	{
		this(); // invoke default C'tor that reads in dictionary and inits output tree
		Random rand = new Random( ); // seed generator so we get SAME random sequence each object!
		this.dimension = dimension; // our board is to be an n x n board
		board = new String[dimension][dimension];
		for (int r = 0 ; r < board.length ; ++r )
			for (int c = 0 ; c < board[r].length ; ++ c)
				board[r][c] = new String( alphabet[ rand.nextInt( alphabet.length ) ] );
	}

	// ---------------------------------------------------------------------------------------------------------
	// 3rd C'tor initializes from a text input file
	public Boggle( String inFileName )
	{
		this(); // invoke default C'tor that reads in dictionary and ints output tree
		readBoggleFile( inFileName );
	}

	private void readBoggleFile(String inFileName )
	{
		FileReader fr = null;		/* actual disk I/O */
		BufferedReader br = null;   /* buffers on top of fr for efficiency */
		StreamTokenizer st = null;  /* tokenizes br */
		int wordsRead = 0;

		try
		{
			fr =new FileReader( inFileName );
			br = new BufferedReader( fr );
			st = new StreamTokenizer( br );
		}
		catch (Exception e)
		{
			System.out.println("Can't open Boggle input file: " + inFileName );
			System.exit(0);
		}


		try
		{
			//read dimension from top of input file

			st.nextToken();
			dimension = (int)st.nval; // # of rows and cols at top of file
			board = new String[dimension][dimension];

			// now read the matrix values row by row

			for (int row=0 ; row<board.length ; ++row )
			{
				for (int col=0 ; col<board[row].length ; ++col )
				{
			 		if (st.nextToken() != StreamTokenizer.TT_EOF)
					{
						String w = st.sval; // we expect every token is a string
						board[row][col] = w;
					}
				}
			}

		}
		catch( Exception e)
		{
			System.out.print("I/O Exception in Boggle input file" );
			System.exit(0);
		}

	} // END READBOGGLEFILE

	public int getDimension()
	{
		return dimension;
	}
	// ---------------------------------------------------------------------------------------------------------
	// Solve:  simple loop visits every cell in the grid and calls solveHelper from that cell

	public void solve()
    {

	}

	// ---------------------------------------------------------------------------------------------------------
	/* 	SolveHelper: This method takes a string that has been formed by  a simple path inside the Boggle grid (board).
		This method searches the Dictionary for the string and if the word is a Dictionary word then it is inserted
		into the output tree. If this string was not found in the dictionary then it's "isPrefix" flag is examined.
		Ihe Dictionary search function set this flag during the search. If the string was not a prefix of any word
		in the  Dictionary then no further strings are generated from this string in the Boggle Grid. This is the
		pruning heuristic of the overall algorithm.
	*/

	private void solveHelper( String board[][], String word, int r, int c)
	{

	} // END SOLVEHELPER


	public void printWordsFound()
	{
		System.out.println( "\n" + wordsFound.countNodes() + " dictionary words found on Boggle board: \n");
		wordsFound.inOrderPrint();
		System.out.println();
	}

	public void printBoard()
	{
		System.out.println("==================================B O G G L E   B O A R D==================================");
		for (int r = 0 ; r < board.length ; ++r )
		{
			for (int c = 0 ; c < board[r].length ; ++ c)
				System.out.print( board[r][c] + " " );
			System.out.println();
		}
		System.out.println("============================================================================================");
	}
} // ENd BOGGLE CLASS


