/* Lab7.java

	author: tim hoffman
	date: October 2002
	F02 15200 Solutoin to Lab7
*/
public class Lab7
{
	public static void main( String args[] )
	{
		Boggle board1 = null;
		Clock timer = new Clock();
		int n; // dimension of desired boggle board (OPTIONAL) 
		
		if ( args.length == 0) // nothing on command line
		{
			System.out.println("Must enter either a number or a filename" );
			System.exit(0);
		}
		
		try // assume that if filename is integer it is a dimension NOT a filename
		{
			n = Integer.parseInt( args[0] );
			timer.start();	
			board1 = new Boggle( n ); // C'tor loads scrabble.txt into Tree
			timer.stop();	          // and fills grid with n x n of Random chars
		}
		catch (Exception e ) // assume command args was a filename not a dimension number
		{
			timer.start();	
			board1 = new Boggle( args[0] ); // C'tor loads scrabble.txt into Tree
			timer.stop();                   // and loads grid of letters from command arg input file
		}
		
		// either way we have a Boggle board ready to solve 		
		
		System.out.println( "\nScrabble dictionary tree built in : " + timer + "\n");
		
		board1.printBoard();
		timer.start();
		board1.solve();
		timer.stop();
		System.out.print( "\n" + board1.getDimension() + " x " + board1.getDimension() + " Boggle board solved in: " + timer );
		board1.printWordsFound();
		
	}
}