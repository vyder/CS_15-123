/* 
	DEMO program generates ALL possible strings from the grid and lists them
	to the screen in a numbered list.
	
	Purpose is to demonstrate to students the correct generation of words possible
	from any given grid of letters.
	
	This demo does not implement the pruning hueristic.
*/
public class Demo
{
	public static void main( String args[] )
	{
		System.out.println("\nDEMO OF BRUTE FORCE GENERATION ALL POSSIBLE STRINGS");
		System.out.println("NO SEARCHING/INSERTING/PRUNING IS DONE. JUST A PRINT Of ALL STRINGS\n\n");
		Boggle board1 = null;
		Clock timer = new Clock();
		int n; // dimension of desired boggle board (OPTIONAL) 
		
		if ( args.length == 0) // nothing on command line
		{
			System.out.println("Must enter either a number or a filename" );
			System.exit(0);
		}
		
		try // assume that if filename is integer it is a dimension NOT a filename
		{
			n = Integer.parseInt( args[0] );
			timer.start();	
			board1 = new Boggle( n ); // C'tor loads scrabble.txt into Tree
			timer.stop();	          // and fills grid with n x n of Random chars
		}
		catch (Exception e ) // assume command args was a filename not a dimension number
		{
			timer.start();	
			board1 = new Boggle( args[0] ); // C'tor loads scrabble.txt into Tree
			timer.stop();                   // and loads grid of letters from command arg input file
		}
		
		// either way we have a Boggle board ready to solve 		
		
	
		board1.printBoard();
		timer.start();
		
		// this is a brute force solve that generates ALL possible strings and prints them.
		// it does NOT search any dictionary for them, not does it store anything into the
		// tree of wordsFound.
		// Your solution version should prune the search space using the hueristic and thus
		// only generate a *much much* smaller number of strings to test in the dictionary
		// Your final solution also will NOT print strings as it generates them from the grid.
		// Your ginal solution will instead insert valid words into the foundWords tree then
		// print that tree at the end of the main.  See my solution Lab7.java file.
		
		board1.solve(); // NON HUERISTIC version that prints every word it generates
		timer.stop();
	}
}