
DEMO progam is just a helper progrma that will show you the correct output of the generation 
of all posibble strings from a given grid of letters.

Compile the Demo.jva file then run it with the other class files in same dir.
Try out a few input files on command line or just enter a number on the command line.

Always run this program from the command line:

c:\TEMP>  java Demo

or from the Mac terminal window is fine too.