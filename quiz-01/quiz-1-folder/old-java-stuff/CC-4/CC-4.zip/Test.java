import introExam.ExamIO;
import java.lang.Comparable;
import java.util.*;


public class Test
{
	public static void main(String[] args)
	{
		Iterator allLines = ExamIO.readFile("Enter mappings file name");

		
		while ( allLines.hasNext() )
		{

		}

	} //END MAIN
}