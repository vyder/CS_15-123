#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cdll.h"

/* just a convenience */
void fatal( char * msg )
{
	printf("%s\n",msg);
	exit(EXIT_FAILURE);
}


/* ----------------------------------------------------------------------------
	initList:

*/
void initList(CDLL *list, int (*compare)(void*, void*), void (*print)(void*, int),
			  void (*freeData)(void *))
{
	/* Y O U R   C O D E    H E R E */
	1) set the head pointer in the CDLL struct to NULL
	2) assign each of the incoming function pointers into their respective fields in the CDLL struct
}


/* ----------------------------------------------------------------------------
	insertAtTail:

	wrap the incoming data value in a CDLL_NODE and append that node onto list
	You don't need iteration ANYWHERE in this code.

*/
void insertAtTail(CDLL *list, void *data)
{
	/* Y O U R   C O D E    H E R E */
}



/* ----------------------------------------------------------------------------
	deleteNode:

	Scan list until you find a node that contains the data value passed in.
	Delete that node then return the pointer to it's successor (if CW) or
	of you are going CCW then return pointer to the deadNode's predecessor.
	IF deadnode was the last node then return NULL since there is no succ or pred.

	If no match is found you are responsible to correctly free the element passed
	in since it is NOT permanent as ws only created for the search.

*/
CDLL_NODE * deleteNode(CDLL *list, CDLL_NODE *deadNode, int direction )
{
	/* Y O U R   C O D E    H E R E */
}



/* Observe my solution executable to see how it should look

	You are really just writing the loop etc. becasue the
	printData's are already written and they are the hardest part
*/

void printList( CDLL list, int direction, int mode )
{
	/* Y O U R   C O D E    H E R E */
}



/* ----------------------------------------------------------------------------
	searchList:

	Scan list until you find a node that contains the data value passed in.
	If found return that pointer - otherwise return NULL


*/
CDLL_NODE * searchList( CDLL list, void * target )
{
	/* Y O U R   C O D E    H E R E */
}
